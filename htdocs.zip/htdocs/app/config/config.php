<?php
  // App Root
  define('APPROOT', dirname(dirname(__FILE__)));
  // URL Root
  define('URLROOT', 'http://localhost/');
  // Site Name
  define('SITENAME', 'E-commerce Project Winter 2022');