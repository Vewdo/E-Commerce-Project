<h1>project proposal</h1>           
<h2>names:</h2>
<b>Christopher Benson (2015470)</b>
<b>Jordano Anoia</b>
<h2>What We Want To implement</h2>
<p>
We would like to build an amazon/ebay like online market which allows users to buy items or keep them in a cart to buy later
</p>

<h3>General Implementations</h3>
<ul>
<li>1.	Accounts for the users</li>
<li>2.	2FA</li>
<li>3.	A shopping cart to keep all the items the customer wants to buy (using an SQL database) <span style="color:Chartreuse">(1 feature)</span></li>
<li>4.	A drop-down menu to let users change the language <span style="color:Chartreuse">(1 feature)</span></li>
<li>5.	The ability to pay <span style="color:Chartreuse">(1 feature)</span></li>
</ul>








<h3>Buyers implementations</h3>
<ul>
<li>1.	See, remove and/or modify the number of items in the shopping cart <span style="color:Chartreuse">(3 features)</span></li>
<li>2.	Register</li>
<li>3.	Login</li>
<li>4.	Edit profile <span style="color:Chartreuse">(1 feature)</span></li>
<li>5.	Search catalog <span style="color:Chartreuse">(1 feature)</span></li>
<li>6.	Change between light and dark theme <span style="color:Chartreuse">(1 feature)</span></li>
<li>7.	Save receipts <span style="color:Chartreuse">(1 feature)</span></li>
</ul>

<a href="https://github.com/janoia/E-Commerce-Project">github link</a> 