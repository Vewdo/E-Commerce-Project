<?php require APPROOT . '/views/includes/header.php'; 
?>

<style>
		
		#content{
			background-color: #434343;
			color: black;
			text-decoration: none;
 			font-family: Amazon Ember,Arial,sans-serif; font-weight: bold;
 			font-size: 1.4vw;
		}

		div.closebtn:hover{
			color:  red;
			background-color: #111111;
		}


		.container{
			background-color: #1d1b1b;
		}
		
		strong{
			color: white;
		}

		.row1, .row2, .row3{
			background-color: #000;
			margin-top: 80px;
			display: flex;
		}

		p{
			color: white;
		}

		a{
			color: black;
			text-decoration: none;
		}

		a:hover{
			color: black;
			text-decoration: none;
		}

		article{
			margin-right: 20px;
			margin-top: 10px;
		}

		article img{
			width=132px;
			 height= 132px;
		}

		article:hover{
			border-color: #66afe9;
 	 		outline: 0;
  			box-shadow: inset 0 0 5px rgba(25, 141, 255, 0.6), 0 0 8px rgba(102, 175, 233, 0.6);
		}

		a, a:hover, a:active, a:visited, a:focus {
			text-decoration: none;
		}

		a span{
			text-decoration: none;
			color: black;
		}

		a span:hover, a span:active, a span:focus, a span:visited, a article{
			text-decoration: none;
			color: black;
		}


		.categories ul {
  			list-style-type: none;
 			margin: 0;
  			padding: 0;
  			overflow: hidden;
  			background-color: #333;
		}

		.categories li {
		  float: left;
		}

		.categories li a {
		  display: block;
		  color: white;
		  text-align: center;
		  padding: 0px 16px 0px 5px;
		  text-decoration: none;
		}

		.categories a:hover{
			color: gray;
		}

		#colors{
			cursor:pointer;
		}

		.button{
			margin-top: 61px;
			transition: all 0.75s ease;
			display:block;
  		height: 80px;
  		width: 80px;
  		border-radius: 50%;
  		background-color: rgba(255, 254, 254, 0.6);
  		display: flex;
  		flex-direction: column;
  		justify-content: center;
  		text-align: center;
  		text-decoration: none;
		}

		.button:hover{
  		background-color: rgba(131, 128, 128, 0.6);
		}

		.button2{
			margin-top: 61px;
			transition: all 0.75s ease;
			display:block;
  		height: 40px;
  		width: 40px;
  		border-radius: 50%;
  		background-color: rgba(255, 254, 254, 0.6);
  		display: flex;
  		flex-direction: column;
  		justify-content: center;
  		text-align: center;			
		}

		.button2:hover{
  		background-color: rgba(131, 128, 128, 0.6);
		}

		.icons{
			display: flex;
			width:100px; 
			margin:0 auto;
			
		}

		.end{
			box-shadow: 0 50vh 0 50vh #000;
			background-color: #161616;
			color: white;
			text-align: center;
			font-size: 0.8vw;
		}

		.sidenav {
		  height: 100%; /* 100% Full-height */
		  width: 0; /* 0 width - change this with JavaScript */
		  position: fixed; /* Stay in place */
		  z-index: 1; /* Stay on top */
 		 	top: 0; /* Stay at the top */
		  left: 0;
		  background-color: #111; /* Black*/
		  overflow-x: hidden; /* Disable horizontal scroll */
		  padding-top: 60px; /* Place content 60px from the top */
		  transition: 0.5s; /* 0.5 second transition effect to slide in the sidenav */
		}

		/* The navigation menu links */
		.sidenav a {
		  padding: 8px 8px 8px 32px;
		  text-decoration: none;
		  font-size: 25px;
		  color: #818181;
		  display: block;
		  transition: 0.3s;
		}

		/* When you mouse over the navigation links, change their color */
		.sidenav a:hover {
		  color: #f1f1f1;
		}

		/* Position and style the close button (top right corner) */
		.sidenav .closebtn {
  		position: absolute;
  		top: 0;
  		right: 25px;
  		font-size: 36px;
  		margin-left: 50px;
		}

		/* Style page content - use this if you want to push the page content to the right when you open the side navigation */
		#main {
		  transition: margin-left .5s;
		  padding: 20px;
		}

		/* On smaller screens, where height is less than 450px, change the style of the sidenav (less padding and a smaller font size) */
		@media screen and (max-height: 450px) {
		  .sidenav {padding-top: 15px;}
		  .sidenav a {font-size: 18px;}
		}

		.sidenav {
		  height: 100%;
		  width: 0;
		  position: fixed;
		  z-index: 1;
		  top: 0;
		  left: 0;
		  background-color: #111;
		  overflow-x: hidden;
		  transition: 0.5s;
		  padding-top: 60px;
		}

		.sidenav a {
		  padding: 8px 8px 8px 32px;
		  text-decoration: none;
		  font-size: 25px;
		  color: #818181;
		  display: block;
		  transition: 0.3s;
		  text-decoration: none;
		}

		.sidenav a:hover {
		  color: #f1f1f1;
		  text-decoration: none;
		  background-color: #373737;
		}

		.sidenav:active{
			color: #818181;
			text-decoration: none;
		}

		.sidenav a:focus{
			color: #f1f1f1;
			text-decoration: none;
		}

		.sidenav .closebtn {
		  position: absolute;
		  top: 0;
		  right: 25px;
		  font-size: 36px;
		  margin-left: 50px;
		}

		@media screen and (max-height: 450px) {
		  .sidenav {padding-top: 15px;}
		  .sidenav a {font-size: 18px;}
		}
</style>

<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" type="image/x-icon" href="https://cdn.discordapp.com/attachments/885822597810511883/942819800520986624/20220214_232501.jpg">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="jquery-3.5.1.min.js"></script>
     <script src="Main.js"></script> 
     <link rel="stylesheet" href="Main.css">
	<title>Main Page</title>

</head>
<body>
<div id="content">
	<header style="background-color: none;">

	<div style="" class="menu">
		<nav style="margin-bottom: 0px;" class="navbar navbar-inverse">
			<a class="navbar-brand" href="#">WebSiteName</a>
				<ul class="nav navbar-nav"; style="display: inline-block;white-space:nowrap;">
      				<li class="active"><a href="#">Home</a></li>
      				<li><a href=".\views\Main\home.php">Page 1</a></li>
     				<li><a href="#">Page 2</a></li>
      				<li><a href="#"style="margin-right: 25px;">Page 3</a></li>  
      				<li><form action="/action_page.php" class="navbar-inner" id="form1" onsubmit="submitted()">     				
    				<input type="text" id="searchBox" name="fname" size="50">
    				</li>
    				<button type="submit" form="form1" value="Submit" id="search" style="font-size: larger;"><svg style="height:1.17em;" viewBox="0 0 12 13"><g stroke-width="2" stroke="#999999" fill="none"><path d="M11.29 11.71l-4-4"/><circle cx="5" cy="5" r="4"/></g></svg></button></li>
    			</form>   					
    			</ul>


    			<ul class="nav navbar-nav navbar-right" style="margin-right: 0px;">
    				<li class="nav-item"><a class="nav-link" href="#"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-plus-fill" viewBox="0 0 16 16">
  				<path d="M1 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
  				<path fill-rule="evenodd" d="M13.5 5a.5.5 0 0 1 .5.5V7h1.5a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0V8h-1.5a.5.5 0 0 1 0-1H13V5.5a.5.5 0 0 1 .5-.5z"/>
				</svg>Sign Up</a></li>
      				<li class="nav-item"><a class="nav-link" href="#"><i class="fas fa-sign-in-alt"></i> Login</a></li>
					<li><a href="#" style="padding-bottom: 0; top: -2px;"><span class="glyphicon glyphicon-shopping-cart" style="-webkit-filter: invert(1);filter: invert(1);margin-right: 15px;margin-left: 10px;"></span></a></li>
    			</ul>
		</nav>		
	</div>

		<div class="categories">
			<nav>
				<ul style="font-size: 0.9vw;">
					<li><a href="#">Sports</a></li>
					<li><a href="#">Electronics</a></li>
					<li><a href="#">Outdoors</a></li>
					<li><a href="#">Toys</a></li>
					<li><a href="#">Arts</a></li>
					<li><a href="#">Garden</a></li>
				</ul>
			</nav>
		</div>
</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="#">About</a>
  <a href="#">Services</a>
  <a href="#">Clients</a>
  <a href="#">Contact</a>
</div>
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
<span onclick="transition('MainPage.html')" id="trans"></span>


</header>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="#">About</a>
  <a href="#">Services</a>
  <a href="#">Clients</a>
  <a href="#">Contact</a>
</div>

<?php
echo'<script>
  function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
  document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
  document.body.style.backgroundColor = "white";
}

function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}

</script>';
?>
<div class="container">
	
<h1><strong>Popular right now</strong></h1>


<div class="row1">
	
<a href="#" class="button" style="text-decoration: none;"><span class="glyphicon glyphicon-menu-left"></span></a>

<a href="#" style="text-decoration:none">
<article style="margin-right: 20px;margin-left: 50px;margin-top: 10px;">
	<img src="https://jazwaresv2.s3.amazonaws.com/media/POKEMON_PIKACHU_OK.png" width="132px" height="132px">
	<p>34 CAD</p>
</article>
</a>

<a href="#" style="text-decoration:none">
<article>
	<img src="https://www.pngkey.com/png/detail/1-19334_free-png-dell-laptop-png-images-transparent-dell.png" width="132px" height="132px">
	<p>340 CAD</p>
</article>
</a>

<a href="#" style="text-decoration:none">
<article>
	<img src="https://i.redd.it/ggo3otstnad61.png" width="132px" height="132px">
	<p>46 CAD</p>
</article>
</a>

<a href="#" style="text-decoration:none">
<article>
	<img src="https://oasis.opstatics.com/content/dam/oasis/page/2021/operation/1217/homepage/mo/02-OnePlus-9.jpg" width="132px" height="132px">
	<p>640 CAD</p>
</article>
</a>

<a href="#" style="text-decoration:none">
<article>
	<img src="https://www.apple.com/newsroom/images/product/iphone/standard/Apple_iPhone-13-Pro_Colors_09142021_big.jpg.slideshow-large_2x.jpg" width="132px" height="132px">
	<p>730 CAD</p>
</article>
</a>

<a href="#" style="text-decoration:none">
<article style="margin-right: 50px;margin-top: 10px;">
	<img src="https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/5430446d-d0da-4d13-95e8-a5d0dd773304/air-force-1-shadow-se-womens-shoe-sWkWmK.jpg" width="132px" height="132px">
	<p>600 CAD</p>
</article>
</a>



<a href="#" class="button" style="text-decoration: none;"><span class="glyphicon glyphicon-menu-right"></span></a>
</div>


<h1><strong>On Sale</strong></h1>

<div class="row2">

	
<a href="#" class="button" style="text-decoration: none;"><span class="glyphicon glyphicon-menu-left"></span></a>

<a href="#" style="text-decoration:none">
<article style="margin-right: 20px;margin-left: 50px;margin-top: 10px;">
	<img src="https://jazwaresv2.s3.amazonaws.com/media/POKEMON_PIKACHU_OK.png" width="132px" height="132px">
	<p>34 CAD</p>
</article>
</a>

<a href="#" style="text-decoration:none">
<article>
	<img src="https://www.pngkey.com/png/detail/1-19334_free-png-dell-laptop-png-images-transparent-dell.png" width="132px" height="132px">
	<p>340 CAD</p>
</article>
</a>

<a href="#" style="text-decoration:none">
<article>
	<img src="https://i.redd.it/ggo3otstnad61.png" width="132px" height="132px">
	<p>46 CAD</p>
</article>
</a>

<a href="#" style="text-decoration:none">
<article>
	<img src="https://oasis.opstatics.com/content/dam/oasis/page/2021/operation/1217/homepage/mo/02-OnePlus-9.jpg" width="132px" height="132px">
	<p>640 CAD</p>
</article>
</a>

<a href="#" style="text-decoration:none">
<article>
	<img src="https://www.apple.com/newsroom/images/product/iphone/standard/Apple_iPhone-13-Pro_Colors_09142021_big.jpg.slideshow-large_2x.jpg" width="132px" height="132px">
	<p>730 CAD</p>
</article>
</a>

<a href="#" style="text-decoration:none">
<article style="margin-right: 50px;margin-top: 10px;">
	<img src="https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/5430446d-d0da-4d13-95e8-a5d0dd773304/air-force-1-shadow-se-womens-shoe-sWkWmK.jpg" width="132px" height="132px">
	<p>600 CAD</p>
</article>
</a>



<a href="#" class="button" style="text-decoration: none;"><span class="glyphicon glyphicon-menu-right"></span></a>
</div>


<h1><strong>You might like</strong></h1>

<div class="row3">

	
<a href="#" class="button" style="text-decoration: none;"><span class="glyphicon glyphicon-menu-left"></span></a>

<a href="#" style="text-decoration:none">
<article style="margin-right: 20px;margin-left: 50px;margin-top: 10px;">
	<img src="https://jazwaresv2.s3.amazonaws.com/media/POKEMON_PIKACHU_OK.png" width="132px" height="132px">
	<p>34 CAD</p>
</article>
</a>

<a href="#" style="text-decoration:none">
<article>
	<img src="https://www.pngkey.com/png/detail/1-19334_free-png-dell-laptop-png-images-transparent-dell.png" width="132px" height="132px">
	<p>340 CAD</p>
</article>
</a>

<a href="#" style="text-decoration:none">
<article>
	<img src="https://i.redd.it/ggo3otstnad61.png" width="132px" height="132px">
	<p>46 CAD</p>
</article>
</a>

<a href="#" style="text-decoration:none">
<article>
	<img src="https://oasis.opstatics.com/content/dam/oasis/page/2021/operation/1217/homepage/mo/02-OnePlus-9.jpg" width="132px" height="132px">
	<p>640 CAD</p>
</article>
</a>

<a href="#" style="text-decoration:none">
<article>
	<img src="https://www.apple.com/newsroom/images/product/iphone/standard/Apple_iPhone-13-Pro_Colors_09142021_big.jpg.slideshow-large_2x.jpg" width="132px" height="132px">
	<p>730 CAD</p>
</article>
</a>

<a href="#" style="text-decoration:none">
<article style="margin-right: 50px;margin-top: 10px;">
	<img src="https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/5430446d-d0da-4d13-95e8-a5d0dd773304/air-force-1-shadow-se-womens-shoe-sWkWmK.jpg" width="132px" height="132px">
	<p>600 CAD</p>
</article>
</a>


<a href="#" class="button" style="text-decoration: none;"><span class="glyphicon glyphicon-menu-right"></span></a>
</div>

</div>

<br>

<footer style="background-color: #263238 !important;color: white;">
	Website made for E-commerce 

<div class="icons">

<a href="#" class="button2" style="margin: 0 auto;"><svg xmlns="http://www.w3.org/2000/svg" width="40px" height="40px" fill="currentColor" class="bi bi-github" viewBox="0 0 16 16">
  <path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.012 8.012 0 0 0 16 8c0-4.42-3.58-8-8-8z" />
</svg></span></a>

<a href="#" class="button2" style="color: #4E5D94;margin: 0 auto;"><svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-discord" viewBox="0 0 16 16">
  <path d="M13.545 2.907a13.227 13.227 0 0 0-3.257-1.011.05.05 0 0 0-.052.025c-.141.25-.297.577-.406.833a12.19 12.19 0 0 0-3.658 0 8.258 8.258 0 0 0-.412-.833.051.051 0 0 0-.052-.025c-1.125.194-2.22.534-3.257 1.011a.041.041 0 0 0-.021.018C.356 6.024-.213 9.047.066 12.032c.001.014.01.028.021.037a13.276 13.276 0 0 0 3.995 2.02.05.05 0 0 0 .056-.019c.308-.42.582-.863.818-1.329a.05.05 0 0 0-.01-.059.051.051 0 0 0-.018-.011 8.875 8.875 0 0 1-1.248-.595.05.05 0 0 1-.02-.066.051.051 0 0 1 .015-.019c.084-.063.168-.129.248-.195a.05.05 0 0 1 .051-.007c2.619 1.196 5.454 1.196 8.041 0a.052.052 0 0 1 .053.007c.08.066.164.132.248.195a.051.051 0 0 1-.004.085 8.254 8.254 0 0 1-1.249.594.05.05 0 0 0-.03.03.052.052 0 0 0 .003.041c.24.465.515.909.817 1.329a.05.05 0 0 0 .056.019 13.235 13.235 0 0 0 4.001-2.02.049.049 0 0 0 .021-.037c.334-3.451-.559-6.449-2.366-9.106a.034.034 0 0 0-.02-.019Zm-8.198 7.307c-.789 0-1.438-.724-1.438-1.612 0-.889.637-1.613 1.438-1.613.807 0 1.45.73 1.438 1.613 0 .888-.637 1.612-1.438 1.612Zm5.316 0c-.788 0-1.438-.724-1.438-1.612 0-.889.637-1.613 1.438-1.613.807 0 1.451.73 1.438 1.613 0 .888-.631 1.612-1.438 1.612Z"/>
</svg></span></a>
		
</div>

<div class="end">&#169;2022 Copyright: Yuyuko</div>

</footer>
</div>
