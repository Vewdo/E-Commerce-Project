<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
  padding-right: 35px;
  padding-left: 35px;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}

@font-face {
font-family: "CatAndFox";
src: url("fac.ttf") format("ttf"),
url("fac.otf") format("opentype"),
}

a{
    -webkit-touch-callout: none;
    -webkit-user-select: none; 
    -khtml-user-select: none; 
    -moz-user-select: none; 
    -ms-user-select: none; 
    user-select: none;
}
</style>
</head>
<body>

  <header>
        <nav style="margin-bottom: 0px;" class="navbar navbar-inverse">
        <a class="navbar-brand" href="/Main/Home" style="background-color: #333333">E-commerce project</a>
            <ul class="nav navbar-nav">
                <li style="background-color: #222222;"><a href="/Main/timeline">Timeline</a></li>
                <li><a href="/Contact/about">About</a></li>
                <li><a href="/Contact/contactus">Contact Us</a></li>
                <li><a href="/Site/MainPage">Page</a></li>
            </ul>
        </nav>
  </header>

<h2>Timeline Table</h2>

<table>
  <tr>
    <th>Student</th>
    <th>Student ID</th>
    <th>Task</th>
    <th>Timeline</th>
  </tr>
  <tr>
    <td>Ben Shappiro</td>
    <td>3150987</td>
    <td>Facts and Logic</td>
    <td>Germany</td>
  </tr>
  <tr>
    <td>Christopher Benson</td>
    <td>2015470</td>
    <td>Backend</td>
    <td>2 weeks</td>
  </tr>
  <tr>
    <td>Jordano Anoia</td>
    <td>Roland Mendel</td>
    <td>Front-end</td>
    <td>1 week</td>
  </tr>
</table>

</body>
</html>